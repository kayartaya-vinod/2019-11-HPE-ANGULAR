import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dotnet',
  templateUrl: './dotnet.component.html',
  styleUrls: ['./dotnet.component.css']
})
export class DotnetComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
