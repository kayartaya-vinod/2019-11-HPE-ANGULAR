import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hibernate',
  templateUrl: './hibernate.component.html',
  styleUrls: ['./hibernate.component.css']
})
export class HibernateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
