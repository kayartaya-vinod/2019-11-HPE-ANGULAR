import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'spring',
  templateUrl: './spring.component.html',
  styleUrls: ['./spring.component.css']
})
export class SpringComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
